<?php
	$url = "panel/";
	header('Location: '.$url);
	exit;
?>