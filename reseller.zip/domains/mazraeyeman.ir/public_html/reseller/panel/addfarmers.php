<?php
error_reporting(0);
session_start();
ob_start();

define("includesfile","true");
require("../includes/admin_functions.php");

adminlogin("","loginckeck");


$fileaddress = 'addfarmers';
if(adminmenus("checkaccess","reseller")!=="1"){
	header("Location: index.php");
	exit;
}//EndIf

$page_sess = $_GET['sess'];
if(empty($page_sess) or $page_sess!==$_SESSION['adminlogin_session']){
	header("Location: farmersmanage.php");
	exit;
}//EndIf

$save_check = $_GET['save'];
if($save_check=="true"){
	
	$name = safe_enter($_POST['name']);
	$nationalcode = safe_enter($_POST['nationalcode']);
	$mobile = safe_enter($_POST['mobile']);
	$email = safe_enter($_POST['email']);
	$state = safe_enter($_POST['state']);
	$city = safe_enter($_POST['city']);
	$address = safe_enter($_POST['address']);
	$location = safe_enter($_POST['location']);
	$unit = safe_enter($_POST['unit']);
	$area = safe_enter($_POST['area']);
	$fathername = safe_enter($_POST['fathername']);
	$tell = safe_enter($_POST['tell']);
	$sh_bime = safe_enter($_POST['sh_bime']);
	$status = safe_enter($_POST['status']);
	////////////////////////////////////////
	$error_check = "";
	
	if(empty($name) or empty($nationalcode) or empty($mobile) or empty($state) or empty($city) or empty($address) or empty($location) or empty($unit) or empty($area) or empty($state)){
		echo '<img src="images/error4.png" style=" width:15px; height:15px; margin:0 0 -4px 5px;" /><b>خطا :</b> تکمیل موارد ستاره دار الزامی میباشد.';
		$error_check = "true";
		exit;
	}//EndIF	
	if(!empty($mobile) and !is_numeric($mobile)){
		echo '<img src="images/error4.png" style=" width:15px; height:15px; margin:0 0 -4px 5px;" /><b>خطا :</b> تلفن همراه وارد شده صحیح نمی باشد.';
		$error_check = "true";
		exit;	
	}//EndIf	
	if(!empty($email) and emailvalidate($email)==false){
		echo '<img src="images/error4.png" style=" width:15px; height:15px; margin:0 0 -4px 5px;" /><b>خطا :</b> ایمیل وارد شده صحیح نمی باشد.';
		$error_check = "true";
		exit;
	}//EndIF
	
	
	if(empty($error_check)){
		$result = db_query("SELECT `username` FROM `db_farmers` WHERE `username`='$mobile' LIMIT 1" , "select");
		if(mysqli_num_rows($result)==0){
			
			if($status=="active"){
				$status = "active";
			}else{
				$status = "deactivated";	
			}//EndIF
			
			$username = $mobile;
			$password = hash_func($mobile);
			$resellercode = intval($_SESSION['adminlogin_id']);
			
			if(db_query("INSERT INTO `db_farmers` (`id`, `username`, `password`, `name`, `fathername`, `nationalcode`, `sh_bime`, `mobile`, `tell`, `email`, `state`, `city`, `address`, `unit`, `area`, `location`, `reg_date`, `last_visit`, `resellercode`, `stream`, `pay`, `status`) VALUES (NULL, '$username', '$password', '$name', '$fathername', '$nationalcode', '$sh_bime', '$mobile', '$tell', '$email', '$state', '$city', '$address', '$unit', '$area', '$location', '".time()."', '', '$resellercode', '0', '0', '$status');","insert")){
				adminlog("Add Farmers | User=$mobile");
				echo '<img src="images/ok.png" style=" width:15px; height:15px; margin:0 0 -4px 5px;" /><b>تبریک! :</b> کشاورز جدید با موفقیت ثبت شد.';
				?>
                	<script>setTimeout("location.href='" + "farmersmanage.php" + "'", 3000);</script>	
                <?php
			}//EndIF
		
		}else{
			echo '<img src="images/error4.png" style=" width:15px; height:15px; margin:0 0 -4px 5px;" /><b>خطا :</b> این نام کاربری(شماره موبایل) قبلا ثبت شده است.';
			$error_check = "true";
			exit;		
		}
	}//EndIF
	exit;
}//EndIf
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="fa" xml:lang="fa" dir="rtl">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="content-language" content="fa" />    
	<title>اضافه کردن کشاورز</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
	<meta name="robots" content="noindex, nofollow" />    
	<link rel="shortcut icon" href="images/favicon.png" />
    <link rel="icon" type="image/x-icon" href="images/favicon.png" />
	<link rel="stylesheet" type="text/css" href="css/page.css" />
	<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script> 
    <script type="text/javascript" src="js/ajax.js"></script>
 <!--[if lt IE 9]>  
    	<script src="js/html5.js"></script>  
    	<script src="js/css3-mediaqueries.js"></script>  
  	<![endif]--> 
	<script>	
				
		function submit_check(){
			var error_result;		
			var name = document.getElementById('name').value;
			var nationalcode = document.getElementById('nationalcode').value;
			var mobile = document.getElementById('mobile').value;
			var email = document.getElementById('email').value;
			var state = document.getElementById('state').value;
			var city = document.getElementById('city').value;
			var address = document.getElementById('address').value;
			var location = document.getElementById('location').value;
			var unit = document.getElementById('unit').value;
			var area = document.getElementById('area').value;
			var status = $("input[name=status]:checked").val();

			
			if(isEmpty(name)==true || isEmpty(nationalcode)==true || isEmpty(mobile)==true || isEmpty(state)==true || isEmpty(city)==true || isEmpty(address)==true || isEmpty(location)==true || isEmpty(unit)==true || isEmpty(area)==true || isEmpty(status)==true){	
				alert('خطا : تکمیل موارد ستاره دار الزامی میباشد.');
				error_result = "error";
			}//EndIf
				
			if(isEmpty(error_result)==true){
				if(nationalcode.length < 10){
					alert('خطا : کد ملی وارد شده کمتر از 10 کارکتر میباشد.');
					error_result = "error";		
				}//ENdIF
				if(mobile.length < 11){
					alert('خطا : تلفن همراه وارد شده کمتر از 11 کارکتر میباشد.');
					error_result = "error";		
				}//ENdIF
				if(isEmpty(email)==false && validateEmail(email)==false){
					alert('خطا : ایمیل وارد شده صحیح نمی باشد.');				
					error_result = "error";						
				}//EndIf				
			}//EndIf			
			
			
			
			if(isEmpty(error_result)==true){
				form_ajax();
			}else{
				form_ajax('false');
			}//EndIf
		}//EndFunction

    </script>       
</head>
<body><center>

	<div class="top_div"></div>
       
    <div class="topmanager_div">
    	<div class="topmanager_body">
            <div class="topmanager_div_right fr">
                <?php echo topadmininfo(); ?>  
            </div><!--topmanager_div_right-->
            <div class="topmanager_div_left fl">
                <div class="tmdl_box1 fr">
                    <a href="index.php" title="صفحه اصلی مدیریت"><div class="tmdl_b1_items fl "><div class="tmld_b1_mainpage"></div><p>( صفحه اصلی )</p></div></a>
                    <a href="#" title="مشاهده سایت"><div class="tmdl_b1_items fl"><div class="tmld_b1_website"></div><p>( مشاهده سایت )</p></div></a>
                </div><!--tmdl_box1-->
            </div><!--topmanager_div_left--> 
    	</div><!--topmanager_body-->   
    </div><!--topmanager_div-->
    
    
	<div class="father_div">
    	
        <div class="logininfo_div fr">
			<div class="logininfo_date fr"><div></div><b>امروز :</b> <?php echo date_analysis("6",time()); echo " (<b>".getip()."</b>)"; ?></div>
            <div class="logininfo_timer fr"><div></div><p><b>زمان باقيمانده :</b></p><p id="countbox1"></p><b onClick="LoginTimerReset();" style="cursor:pointer;">( بازبینی زمان )</b></div>
        </div><!--logininfo_div-->
        
		<div class="menudiv fr">        
			<?php
				require("_adminmenu.php");			
			?>                                
        </div><!--menudiv-->
        
        <div class="bodydiv fl">        
        	<div class="bodydiv_item fr">
            <div class="bodydiv_item_title fr"><div><img src="images/icon6.png" />اضافه کردن کشاورز</div></div>
            <div class="bodydiv_page_loading fr" id="bodydiv_page_loading"><img src="images/loading3.gif" /><p>در حال دریافت اطلاعات ...</p></div>
            <div class="bodydiv_item_body fr" id="bodydiv_item_body">            
                
            	<script>adminpage_loader(1);</script>
  
               <div class="addadmin_div fr">
                    <form id="form_ajax" method="post" action="addfarmers.php?sess=<?php echo $page_sess; ?>&save=true">
                    	<p>نام و نام خانوادگی : (*)</p><input type="text" name="name" id="name" dir="rtl" style="margin-right:14px;" /><p style="color:#A8A8A8">(فارسی)</p><br style="clear:both" />   
						<p>نام پدر : </p><input type="text" name="fathername" id="fathername" dir="rtl" style="margin-right:52px;" /><p style="color:#A8A8A8">(فارسی)</p><br style="clear:both" />   
						<p>کد ملی : (*)</p><input type="number" name="nationalcode" id="nationalcode" dir="ltr" style="margin-right:52px;" /><br style="clear:both" />    
                        <p>تلفن همراه : (*)</p><input type="number" name="mobile" id="mobile" dir="ltr" style="margin-right:46px;" /><p style="color:#A8A8A8">(نمونه : 09170001234)</p><br style="clear:both" />
						<p>تلفن ثابت :</p><input type="number" name="tell" id="tell" dir="ltr" style="margin-right:52px;" /><br style="clear:both" />
                        <p style="margin-left:52px;">ایمیل : </p><input type="text" name="email" id="email" dir="ltr" onFocus="this.style='border:1px dashed #B0CEE1;'" /><br style="clear:both" />
						<p style="margin-left:52px;">شماره بیمه : </p><input type="text" name="sh_bime" id="sh_bime" dir="ltr" onFocus="this.style='border:1px dashed #B0CEE1;'" /><br style="clear:both" />
                        
                        <br style="clear:both" /><hr style="width:99%; border-top:1px solid #ccc;" /><br style="clear:both" />
						
						<p>استان : (*)</p><input type="text" name="state" id="state" dir="rtl" style="margin-right:52px;" /><br style="clear:both" /> 
						<p>شهر : (*)</p><input type="text" name="city" id="city" dir="rtl" style="margin-right:52px;" /><br style="clear:both" /> 
						<p>آدرس : (*)</p><textarea name="address" id="address" style="margin-right:52px;"></textarea><br style="clear:both" />
						<br style="clear:both" />
						<p>موقعیت جغرافیایی : (*)</p><input type="text" name="location" id="location" dir="rtl" style="margin-right:12px;" /><br style="clear:both" /> 
						<p>واحد : (*)</p><select name="unit" id="unit" style="margin-right:52px;"><option value="hectare">هکتار</option><option value="meter">متر مربع</option></select><br style="clear:both" />
						<p>مساحت : (*)</p><input type="number" name="area" id="area" dir="ltr" style="margin-right:52px;" /><br style="clear:both" /> 
						
						 <br style="clear:both" /><hr style="width:99%; border-top:1px solid #ccc;" /><br style="clear:both" />
                        
                        <p>نام کاربری : (*)</p><input type="text" name="username" id="username" style="margin-right:52px;" value="شماره موبایل" disabled /><br style="clear:both" /> 
                        <p style="margin-left:54px;">رمز عبور : (*)</p><input type="text" name="pass1" id="pass1" value="َشماره موبایل"  disabled /><br style="clear:both" />
                        
                        <br style="clear:both" /><br style="clear:both" />
                        
                        <br style="clear:both" /><hr style="width:100%; border-top:1px solid #ccc;" /><br style="clear:both" />
                        
                        <p>وضعیت : (*)</p><br style="clear:both" />
                        <input type="radio" name="status" value="active" style="float:right; margin:13px 7px 0 0;" checked="checked" /><p>فعال</p>
                        <input type="radio" name="status" value="deactivated" style="float:right; margin:13px -15px 0 0;" /><p>غیر فعال</p>
                        
                        <br style="clear:both" />
                        <br style="clear:both" /><hr style="width:100%; border-top:1px solid #ccc;" /><br style="clear:both" />
                        
                        <input type="submit" name="formsubmit" value="اضافه کردن" class="addadmin_formsubmit fr" onClick="submit_check();" />
                        <div id="form_ajax_result"></div>
                    </form>
                </div><!--addadmin_div-->

                
            </div><!--bodydiv_item_body-->
            </div><!--bodydiv_item-->
                            
        </div><!--bodydiv-->    
    <br style="clear:both" />   
    </div><!--father_div-->
    
    
    <div class="footer_div">
    	<div class="copyrightright fr"></div>
    	<p class="copyrightleft fl"><?php echo copyright(); ?></p>
    	
    </div><!--footer_div-->
    
    
    <?php
    
        echo "
            <script>
			adminpage_loader(2);
            document.getElementById('$fileaddress').className='menudiv_item_links_hover fr';
            </script>
           ";
    ?>   

</center></body>
</html>