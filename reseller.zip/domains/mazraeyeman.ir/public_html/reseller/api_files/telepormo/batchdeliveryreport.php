<?php 
include('./telepormo_functions.php');

if(!isset($_GET['tel'])){
    echo "phone number is required";
}elseif(!isset($_GET['correlator'])){
    echo "correlator is required";
}else{
    BatchDeliveryReportFunc("0".intval($_GET['tel']),$_GET['correlator']);
}

?>
