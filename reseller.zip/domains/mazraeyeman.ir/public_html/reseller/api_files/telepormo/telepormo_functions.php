<?php

function NotificationFunc($ftel) {
    $age = array(
        "trans_id"=>        "PROV_154260658628575784191",
        "trans_status"=>    "0",
        "base_price_point"=>"37",
        "shortcode"=>       "null",
        "validity"=>        "1",
        "event_type"=>      "1.2",
        "keyword"=>         "null",
        "serviceid"=>       "4988",
        "chargecode"=>      "TELUSUBCTELMAROOFS",
        "channel"=>         "TAJMI",
        "billed_price_point"=>"",
        "status"=>          "5",
        "datetime"=>        date("Y-m-d h:i:sa"),
        "next_renewal_date"=>date("Y-m-d h:i:sa"),
        "msisdn"=>          $ftel,
    );
    
    echo httpPost('http://10.20.9.187:3400',$age);
}// end Notification function


function BatchDeliveryReportFunc($ftel,$correlator) {
//    curl -X POST \
//    http:// Delivey-Batch-SP_URL
$data='<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <soapenv:Body>
    <notifySmsDeliveryReceipt xmlns="http://www.csapi.org/schema/parlayx/sms/notification/v2_1/local"> <notifySmsDeliveryReceiptCollection> 
        <NotifySmsDeliveryReceipt>
            <correlator>'.$correlator.'</correlator>
            <deliveryStatus>
                <address xmlns="">tel:'.$ftel.'</address>
                <deliveryStatus xmlns="">DeliveredToTerminal</deliveryStatus>
            </deliveryStatus>
        </NotifySmsDeliveryReceipt> 
    <NotifySmsDeliveryReceipt>
        <correlator>'.$correlator.'</correlator>
        <deliveryStatus>
            <address xmlns="">tel:'.$ftel.'</address>
            <deliveryStatus xmlns="">DeliveredToTerminal</deliveryStatus>
    </deliveryStatus> 
    </NotifySmsDeliveryReceipt> 
    </notifySmsDeliveryReceiptCollection>
    </notifySmsDeliveryReceipt>
    </soapenv:Body>
</soapenv:Envelope>';
echo httpPost("http://10.20.9.187:3400",$data);
}// end Notification function







function BatchMOMessageFunc($ftel,$senderName,$msg) {
//curl -X POST \
//    http://MOBATCH_SP_URL
$data = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:loc="http://www.csapi.org/schema/parlayx/sms/send/v4_0/local"> 
    <soapenv:Header/>
    <soapenv:Body>
        <loc:sendSms xmlns="http://tempuri.org/">
            <loc:sendSmsCollection>
                <loc:SendSms>
                    <loc:addresses>'.$ftel.'</loc:addresses>
                    <loc:senderName>'.$senderName.'</loc:senderName>
                    <loc:message>'.$msg.'</loc:message> 
                    <loc:receiptRequest> 
                        <endpoint></endpoint> 
                        <interfaceName></interfaceName> 
                        <correlator></correlator> 
                    </loc:receiptRequest> 
                </loc:SendSms> 
                <loc:SendSms> 
                    <loc:addresses>'.$ftel.'</loc:addresses>
                    <loc:senderName>'.$senderName.'</loc:senderName>
                    <loc:message>'.$msg.'</loc:message> 
                    <loc:receiptRequest> 
                        <endpoint></endpoint> 
                        <interfaceName></interfaceName> 
                        <correlator></correlator> 
                    </loc:receiptRequest> 
                </loc:SendSms> 
            </loc:sendSmsCollection> 
        </loc:sendSms> 
    </soapenv:Body> 
</soapenv:Envelope>';
echo httpPost("http://10.20.9.187:3400",$data);
}// end BatchMOMessage function




function httpPost($url, $data)
{
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}


?>