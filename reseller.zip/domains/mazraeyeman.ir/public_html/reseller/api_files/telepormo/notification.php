<?php 
include('./telepormo_functions.php');

if(isset($_GET['tel'])){
    NotificationFunc("0".intval($_GET['tel']));
}else{
    echo "phone number is required";
}

?>