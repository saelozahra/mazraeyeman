<?php 
include('./telepormo_functions.php');

if(!isset($_GET['tel'])){
    echo "phone number is required";
}elseif(!isset($_GET['name'])){
    echo "Sender Name is required";
}elseif(!isset($_GET['msg'])){
    echo "Message is required";
}else{
    BatchMOMessageFunc("0".intval($_GET['tel']),$_GET['name'],$_GET['msg']);
}

?>
